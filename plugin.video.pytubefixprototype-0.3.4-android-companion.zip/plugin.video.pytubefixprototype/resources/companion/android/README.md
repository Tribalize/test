# PyTubeFix Local Resolver for Android

This folder defines the Android companion boundary used by the Kodi add-on:

- Kodi launches `org.pytubefixprototype.resolver` only when localhost health
  checks fail.
- The launched app accepts `pytubefixresolver://start?port=<port>&token=<token>`.
- It serves `GET /health` and `POST /resolve` on `127.0.0.1` only.
- It stops itself after 45 seconds without a request.

The Android project deliberately has no YouTube add-on handoff.  The native
resolution engine is the remaining platform-specific component: SmartTube's
Java/Android API code cannot be copied into Kodi Python and must be integrated
and tested in this app before this project is shipped as an APK.
