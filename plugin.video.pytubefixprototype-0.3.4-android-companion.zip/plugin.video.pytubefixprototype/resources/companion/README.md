# Local resolver companion

The add-on talks only to an on-demand loopback HTTP API:

* `GET /health` confirms that the selected companion instance owns the token.
* `POST /resolve` accepts `{"watch_url":"https://www.youtube.com/watch?v=..."}`.
* Responses contain a temporary direct media URL.  The companion must not
  proxy media bytes.

Windows bundles a private Python runtime and uses the existing patched
PyTubeFix vendor code.  Android has the same launch/API contract but needs a
native resolver engine before it can be distributed.
