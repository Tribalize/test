# -*- coding: utf-8 -*-
"""Private Windows-only PyTubeFix Kodi prototype."""
from __future__ import print_function

import json
import os
import subprocess
import sys
import time
from urllib.parse import parse_qs, urlencode
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
VENDOR_DIR = os.path.join(ADDON_DIR, "resources", "lib", "vendor")
if VENDOR_DIR not in sys.path:
    sys.path.insert(0, VENDOR_DIR)

COMPANION_PORT = 59401
COMPANION_IDLE_SECONDS = 45
ANDROID_COMPANION_ID = "org.pytubefixprototype.resolver"


def _url(**params):
    return "{}?{}".format(sys.argv[0], urlencode(params))


def _end(content=None):
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def _error(message):
    xbmcgui.Dialog().ok("PyTubeFix Prototype", message)


def _is_android():
    return xbmc.getCondVisibility("System.Platform.Android")


def _companion_settings():
    profile_dir = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
    if not os.path.isdir(profile_dir):
        os.makedirs(profile_dir)
    settings_path = os.path.join(profile_dir, "local_resolver.json")
    try:
        with open(settings_path, "r") as settings_file:
            settings = json.load(settings_file)
    except Exception:
        settings = {}
    token = settings.get("token", "")
    if not token:
        token = os.urandom(24).hex()
        with open(settings_path, "w") as settings_file:
            json.dump({"token": token}, settings_file)
    return token


def _companion_request(path, token, payload=None, timeout=2):
    headers = {"X-PyTubeFix-Token": token}
    data = None
    if payload is not None:
        data = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json"
    request = Request(
        "http://127.0.0.1:{}{}".format(COMPANION_PORT, path),
        data=data,
        headers=headers,
    )
    response = urlopen(request, timeout=timeout)
    return json.loads(response.read().decode("utf-8"))


def _companion_is_ready(token):
    try:
        return bool(_companion_request("/health", token).get("ok"))
    except Exception:
        return False


def _start_android_companion(token):
    data_uri = "pytubefixresolver://start?{}".format(urlencode({
        "port": COMPANION_PORT,
        "token": token,
        "idle_seconds": COMPANION_IDLE_SECONDS,
    }))
    xbmc.executebuiltin(
        "StartAndroidActivity({0},android.intent.action.VIEW,,{1})".format(
            ANDROID_COMPANION_ID,
            data_uri,
        )
    )


def _ensure_companion():
    if not _is_android():
        raise RuntimeError("The local companion is used only on Android.")
    token = _companion_settings()
    if _companion_is_ready(token):
        return token
    _start_android_companion(token)
    for _attempt in range(24):
        time.sleep(0.25)
        if _companion_is_ready(token):
            return token
    raise RuntimeError(
        "The Android Local Resolver companion is not installed or did not start. "
        "Sideload its APK on this phone, tablet, or TV device, then try again."
    )


def _resolve_with_companion(watch_url):
    token = _ensure_companion()
    result = _companion_request("/resolve", token, {"watch_url": watch_url}, timeout=30)
    if not result.get("url"):
        raise RuntimeError(result.get("message", "The local resolver returned no stream URL."))
    return result


def _node_test():
    if not _is_android():
        try:
            import nodejs_wheel.executable
            node = os.path.join(nodejs_wheel.executable.ROOT_DIR, "node.exe")
            version = subprocess.check_output(
                [node, "--version"],
                stderr=subprocess.STDOUT,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            ).decode("utf-8").strip()
            _error("Bundled Windows Node started successfully: {}".format(version))
        except Exception as exc:
            _error("Bundled Windows Node test failed:\n{}".format(exc))
        return
    try:
        _ensure_companion()
        _error("Android Local Resolver started successfully. It will stop after {} seconds idle.".format(COMPANION_IDLE_SECONDS))
    except Exception as exc:
        _error("Android Local Resolver test failed:\n{}".format(exc))


def _search():
    query = xbmcgui.Dialog().input("Search YouTube")
    if not query:
        _end("videos")
        return
    try:
        from pytubefix.contrib.search import Search
        raw_results = Search(query).fetch_query()
        sections = raw_results["contents"]["twoColumnSearchResultsRenderer"]["primaryContents"]["sectionListRenderer"]["contents"]
        renderer = next(section["itemSectionRenderer"] for section in sections if "itemSectionRenderer" in section)
        videos = [row["videoRenderer"] for row in renderer["contents"] if "videoRenderer" in row]
    except Exception as exc:
        _error("Search failed:\n{}".format(exc))
        _end("videos")
        return

    handle = int(sys.argv[1])
    for video in videos:
        try:
            title_runs = video.get("title", {}).get("runs", [])
            title = "".join(run.get("text", "") for run in title_runs) or "Untitled video"
            video_id = video["videoId"]
            watch_url = "https://www.youtube.com/watch?v={}".format(video_id)
            item = xbmcgui.ListItem(label=title)
            item.setProperty("IsPlayable", "true")
            thumbs = video.get("thumbnail", {}).get("thumbnails", [])
            thumbnail = thumbs[-1].get("url", "") if thumbs else ""
            if thumbnail:
                item.setArt({"thumb": thumbnail, "icon": thumbnail})
            duration = video.get("lengthText", {}).get("simpleText", "")
            channel_runs = video.get("ownerText", {}).get("runs", [])
            channel = "".join(run.get("text", "") for run in channel_runs)
            item.setInfo("video", {"title": title, "duration": duration, "studio": channel})
            xbmcplugin.addDirectoryItem(handle, _url(action="play", url=watch_url), item, False)
        except Exception:
            # A malformed individual result must not discard the whole search.
            continue
    _end("videos")


def _play(watch_url):
    try:
        if _is_android():
            stream = _resolve_with_companion(watch_url)
            stream_url = stream["url"]
            mime_type = stream.get("mime_type", "video/mp4")
        else:
            from pytubefix import YouTube
            # Windows uses the originally tested in-process PyTubeFix + bundled
            # Node resolver. No companion process is started on this platform.
            video = YouTube(watch_url, client="MWEB")
            direct_stream = (video.streams.filter(progressive=True, file_extension="mp4")
                             .order_by("resolution").desc().first())
            if direct_stream is None:
                raise RuntimeError("No progressive MP4 stream is available for this video.")
            stream_url = direct_stream.url
            mime_type = "video/mp4"
        item = xbmcgui.ListItem(path=stream_url)
        item.setProperty("IsPlayable", "true")
        item.setMimeType(mime_type)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
    except Exception as exc:
        _error("Playback resolution failed:\n{}".format(exc))
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())


def _root():
    handle = int(sys.argv[1])
    xbmcplugin.addDirectoryItem(handle, _url(action="search"), xbmcgui.ListItem(label="Search videos"), True)
    if _is_android():
        xbmcplugin.addDirectoryItem(
            handle,
            _url(action="node_test"),
            xbmcgui.ListItem(label="Test Android Local Resolver"),
            False,
        )
    _end()


def main():
    params = parse_qs(sys.argv[2][1:]) if len(sys.argv) > 2 else {}
    action = params.get("action", [""])[0]
    if action == "search":
        _search()
    elif action == "play":
        _play(params.get("url", [""])[0])
    elif action == "node_test":
        _node_test()
    else:
        _root()


if __name__ == "__main__":
    main()
